<?php

$username="root";
$password="";
$database_name="login";

$conn=mysqli_connect('localhost',$username,$password,$database_name);
//now check the connection

if(!$conn)
{
	die("Connection Failed:" . mysqli_connect_error());

}

if(isset($_POST['submit']))
{	
	 $uname = $_POST['uname'];
	 $paswd = $_POST['paswd'];
	
	 
	 $sql_query = "INSERT INTO logins (uname,paswd)
	 VALUES ('$uname','$paswd')";

	 if (mysqli_query($conn, $sql_query)) 
	 {
		echo "New Details Entry inserted successfully !";
	 } 
	 else
     {
		echo "Error: " . $sql . "" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>;